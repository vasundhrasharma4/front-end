<html>

    <body>
           <form action="" method="POST" id="form">

<h2>Enter 1st number: </h2><br>
<input type="text" name="number1" ><br>
<h2>Enter 2nd number: </h2><br>
<input type="text" name="number2" ><br>
<h2>Submit to know quadrant</h2>
<input type="Submit" name ="submit"><br>

</form>
<?php


$num1=$_POST['number1'];
$num2=$_POST['number2'];
 
if($num1>0 & $num2>0)
{
    echo("it is 1st quadrant as value of x is positive ".$num1."  and value of y is positive ".$num2);
}
elseif($num1<0 & $num2>0)
{
    echo("it is 2nd quadrant as value of x is negative ".$num1."  and value of y is positive ".$num2);
}
elseif($num1<0 & $num2<0)
{
    echo("it is 3rd quadrant as value of x is negative ".$num1."  and value of y is negative ".$num2);
}
elseif($num1>0 & $num2<0)
{
    echo("it is 4th quadrant as value of x is positive ".$num1."  and value of y is negative ".$num2);
}
elseif($num1==0 & $num2==0)
{
    echo("this point lies at centre as both values are zero.");
}
elseif($num1>0 & $num2==0)
{
    echo(" this point lies on x-axis positive  as the value on y-axis is 0 and value of x-axis is ".$num1);
}
elseif($num1<0 & $num2==0)
{
    echo(" this point lies on x-axis negative  as the value on y-axis is 0 and value of x-axis is ".$num1);
}
elseif($num1==0 & $num2>0)
{
    echo(" this point lies on y-axis positive as the value on x-axis is 0 and value of y-axis is ".$num2);
}
elseif($num1==0 & $num2<0)
{
    echo(" this point lies on y-axis  negative as the value on x-axis is 0 and value of y-axis is ".$num2);
}
else{
    echo("entered number are wrong;");
}



?>


    </body>

</html>
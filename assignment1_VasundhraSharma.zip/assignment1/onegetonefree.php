<html>
    <body>
        <style>
            
        </style>
        
        <form action="" method="POST" id="form">

           <h2>Enter price of Item 1: </h2><br>
           <input type="text" name="number1"><br>
           <h2>Enter price of Item 2: </h2><br>
           <input type="text" name="number2"><br>
           <h2>Submit to get gross price</h2>
           <input type="Submit" name ="submit"><br>

</form>

<?php

#creating two variables as num1 and num2.

$item1=$_POST['number1'];
$item2=$_POST['number2'];

# condition statement if  item 1 is more expensive then 50% off is applied on item 2
  if($item>$item2)
  {
    echo( "As item 2 is less expensive so 50% discount is applicable on that.<br>");
    # 50 % discount = 0.5 and after discount the price will be stored in variable discount
    $discount= 0.5*$item2;
    # printing prices of item 1 and item 2
    echo( "gross price of item 1 is :-  ".$item1."<br>");
    echo( "gross price of item 2 is :-  ".$discount."<br>");
    $gross=$item1+$discount;
    #11% tax on total sale after discount.
    $total=(0.11*$gross)+$gross;
    echo( "gross price of item 1 and 2  :-  ".$total."<br>");

  }

  #condition statement else,   item 2 is more expensive then 50% off is applied on item 1
  else
  {
    echo( "As item 1 is less expensive so 50% discount is applicable on that.<br>");
        # 50 % discount = 0.5 and after discount the price will be stored in variable discount
    $discount=0.5*$item1;
        # printing prices of item 1 and item 2
    echo( "gross price of item 1 is :-  ".$discount."<br>");
    echo( "gross price of item 2 is :-  ".$item2."<br>");
    $gross=$item2+$discount;
    #11% tax on total sale after discount.
    $total=(0.11*$gross)+$gross;
    echo(" gross price of item 1 and 2 is :- ".$total."<br>");
    
  }

 



?>


    </body>

</html>